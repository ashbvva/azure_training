﻿namespace Relecloud.FunctionApp.EventProcessor
{
    public class Event
    {
        public string EventType { get; set; }
        public string EntityId { get; set; }
    }
}